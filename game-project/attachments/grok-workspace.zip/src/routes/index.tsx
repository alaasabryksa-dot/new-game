import { createFileRoute } from "@tanstack/react-router";
import { YaSawwaq } from "@/components/ya-sawwaq";

export const Route = createFileRoute("/")({ component: YaSawwaq });
