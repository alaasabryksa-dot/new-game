import * as THREE from "three";
import { mergeGeometries } from "three/addons/utils/BufferGeometryUtils.js";
import {
  type Hud,
  type Mode,
  type Pax,
  type Phase,
  type PreviewCfg,
  type VehicleId,
  vehicleById,
} from "./types";
import { ROAD_HALF, buildTrack, laneLat, wrapAngle, wrapDelta, type Track } from "./track";

export type GameHandle = {
  getHud: () => Hud;
  setPreview: (cfg: PreviewCfg) => void;
  start: (cfg: PreviewCfg) => void;
  pause: () => void;
  resume: () => void;
  quit: () => void;
  finish: () => void;
  setTouch: (t: { steer: number; throttle: number; brake: number }) => void;
  horn: () => void;
  cycleCam: () => void;
  toggleSound: () => void;
  dispose: () => void;
};

type Npc = {
  alive: boolean;
  kind: VehicleId;
  s: number;
  lane: number;
  laneTarget: number;
  speed: number;
  cruise: number;
  brake: number;
  color: THREE.Color;
  nextLane: number;
};

type Wrong = { s: number; speed: number; lat: number };

const SAVE_KEY = "yasawwaq-save-v1";
const RADAR_LIMIT = 90 / 3.6;
const TOLL_LIMIT = 42 / 3.6;

type Save = { v: 1; bestMoney: number; bestKm: number; bestTrial: number | null; sound: boolean };

function loadSave(): Save {
  const blank: Save = { v: 1, bestMoney: 0, bestKm: 0, bestTrial: null, sound: true };
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return blank;
    const p = JSON.parse(raw) as Partial<Save>;
    if (p.v !== 1) return blank;
    return {
      v: 1,
      bestMoney: Number(p.bestMoney) || 0,
      bestKm: Number(p.bestKm) || 0,
      bestTrial: typeof p.bestTrial === "number" ? p.bestTrial : null,
      sound: p.sound !== false,
    };
  } catch {
    return blank;
  }
}

function writeSave(s: Save) {
  try {
    localStorage.setItem(SAVE_KEY, JSON.stringify(s));
  } catch {
    /* ignore quota */
  }
}

function box(w: number, h: number, d: number, x: number, y: number, z: number) {
  const g = new THREE.BoxGeometry(w, h, d);
  g.translate(x, y, z);
  return g;
}

function merge(parts: THREE.BufferGeometry[]) {
  return mergeGeometries(parts, false) ?? parts[0];
}

const KINDS: VehicleId[] = ["malaky", "taxi", "micro", "tuktuk", "truck"];

function trafficGeoms(kind: VehicleId) {
  const body: THREE.BufferGeometry[] = [];
  const glass: THREE.BufferGeometry[] = [];
  const wheels: THREE.BufferGeometry[] = [];
  const lights: THREE.BufferGeometry[] = [];
  const wheel = () => {
    const g = new THREE.CylinderGeometry(0.34, 0.34, 0.22, 8);
    g.rotateZ(Math.PI / 2);
    return g;
  };
  const addW = (x: number, y: number, z: number, s = 1) => {
    const g = wheel();
    g.scale(s, s, s);
    g.translate(x, y, z);
    wheels.push(g);
  };

  if (kind === "micro") {
    body.push(box(2.05, 1.45, 4.9, 0, 1.2, 0.05));
    glass.push(box(1.85, 0.55, 1.3, 0, 1.85, -1.05));
    glass.push(box(1.7, 0.42, 2.2, 0, 1.78, 0.85));
    lights.push(box(0.2, 0.22, 0.08, -0.75, 0.95, 2.5));
    lights.push(box(0.2, 0.22, 0.08, 0.75, 0.95, 2.5));
    addW(-1.05, 0.36, -1.6, 1.05);
    addW(1.05, 0.36, -1.6, 1.05);
    addW(-1.05, 0.36, 1.5, 1.05);
    addW(1.05, 0.36, 1.5, 1.05);
  } else if (kind === "tuktuk") {
    body.push(box(1.3, 1.15, 2.15, 0, 0.95, 0.05));
    body.push(box(1.35, 0.08, 1.5, 0, 1.58, 0.15));
    glass.push(box(1.15, 0.55, 0.9, 0, 1.25, -0.15));
    lights.push(box(0.12, 0.12, 0.06, -0.45, 0.7, 1.15));
    lights.push(box(0.12, 0.12, 0.06, 0.45, 0.7, 1.15));
    addW(-0.62, 0.3, 0.55, 0.85);
    addW(0.62, 0.3, 0.55, 0.85);
    addW(0, 0.3, -0.85, 0.85);
  } else if (kind === "truck") {
    body.push(box(2.35, 1.55, 7.2, 0, 1.25, 1.35));
    body.push(box(2.2, 1.7, 2.3, 0, 1.45, -3.15));
    glass.push(box(1.9, 0.55, 0.9, 0, 1.9, -3.55));
    lights.push(box(0.22, 0.18, 0.08, -0.8, 0.85, 4.95));
    lights.push(box(0.22, 0.18, 0.08, 0.8, 0.85, 4.95));
    addW(-1.15, 0.42, -3.3, 1.2);
    addW(1.15, 0.42, -3.3, 1.2);
    addW(-1.15, 0.42, 1.2, 1.2);
    addW(1.15, 0.42, 1.2, 1.2);
    addW(-1.15, 0.42, 3.5, 1.2);
    addW(1.15, 0.42, 3.5, 1.2);
  } else {
    body.push(box(1.72, 0.48, 4.25, 0, 0.62, 0));
    body.push(box(1.55, 0.42, 2.05, 0, 1.05, 0.28));
    if (kind === "taxi") body.push(box(0.34, 0.16, 0.34, 0, 1.38, 0.15));
    glass.push(box(1.4, 0.36, 1.15, 0, 1.08, -0.15));
    lights.push(box(0.22, 0.14, 0.06, -0.62, 0.72, 2.12));
    lights.push(box(0.22, 0.14, 0.06, 0.62, 0.72, 2.12));
    addW(-0.78, 0.32, -1.35);
    addW(0.78, 0.32, -1.35);
    addW(-0.78, 0.32, 1.28);
    addW(0.78, 0.32, 1.28);
  }
  return {
    body: merge(body),
    glass: merge(glass),
    wheels: merge(wheels),
    lights: merge(lights),
  };
}

function buildPlayer(kind: VehicleId, hex: string) {
  const g = new THREE.Group();
  g.rotation.order = "YXZ";
  const paint = new THREE.MeshStandardMaterial({ color: hex, roughness: 0.46, metalness: 0.12 });
  const glass = new THREE.MeshStandardMaterial({
    color: "#b7dbe3",
    roughness: 0.08,
    metalness: 0.35,
    transparent: true,
    opacity: 0.78,
  });
  const dark = new THREE.MeshStandardMaterial({ color: "#17191d", roughness: 0.62 });
  const tail = new THREE.MeshStandardMaterial({
    color: "#ff3b3b",
    emissive: "#ff2020",
    emissiveIntensity: 0.9,
  });
  const head = new THREE.MeshStandardMaterial({
    color: "#fff6d8",
    emissive: "#ffe7a8",
    emissiveIntensity: 0.35,
  });
  const wheels: THREE.Mesh[] = [];
  const put = (geo: THREE.BufferGeometry, mat: THREE.Material, x: number, y: number, z: number) => {
    const m = new THREE.Mesh(geo, mat);
    m.position.set(x, y, z);
    g.add(m);
    return m;
  };
  const addWheels = (x: number, z: number, r: number) => {
    const geo = new THREE.CylinderGeometry(r, r, r * 0.7, 12);
    geo.rotateZ(Math.PI / 2);
    for (const sx of [-1, 1]) {
      const m = new THREE.Mesh(geo, dark);
      m.position.set(sx * x, r, z);
      g.add(m);
      wheels.push(m);
    }
  };

  if (kind === "micro") {
    put(new THREE.BoxGeometry(2.05, 1.15, 4.9), paint, 0, 1.05, 0.05);
    put(new THREE.BoxGeometry(1.9, 0.48, 1.35), glass, 0, 1.78, -0.95);
    put(new THREE.BoxGeometry(1.75, 0.4, 2.1), glass, 0, 1.72, 0.9);
    put(new THREE.BoxGeometry(0.22, 0.26, 0.08), tail, -0.72, 0.95, 2.52);
    put(new THREE.BoxGeometry(0.22, 0.26, 0.08), tail, 0.72, 0.95, 2.52);
    put(new THREE.BoxGeometry(0.42, 0.22, 0.08), head, -0.65, 0.95, -2.42);
    put(new THREE.BoxGeometry(0.42, 0.22, 0.08), head, 0.65, 0.95, -2.42);
    addWheels(1.02, -1.55, 0.38);
    addWheels(1.02, 1.5, 0.38);
  } else if (kind === "tuktuk") {
    put(new THREE.BoxGeometry(1.28, 0.9, 2.1), paint, 0, 0.85, 0.05);
    put(new THREE.BoxGeometry(1.4, 0.08, 1.55), paint, 0, 1.55, 0.1);
    put(new THREE.BoxGeometry(1.12, 0.48, 0.85), glass, 0, 1.15, -0.1);
    put(new THREE.BoxGeometry(0.12, 0.12, 0.06), tail, -0.42, 0.62, 1.12);
    put(new THREE.BoxGeometry(0.12, 0.12, 0.06), tail, 0.42, 0.62, 1.12);
    put(new THREE.BoxGeometry(0.2, 0.16, 0.06), head, 0, 0.7, -1.02);
    addWheels(0.62, 0.55, 0.3);
    const geo = new THREE.CylinderGeometry(0.3, 0.3, 0.2, 10);
    geo.rotateZ(Math.PI / 2);
    const m = new THREE.Mesh(geo, dark);
    m.position.set(0, 0.3, -0.85);
    g.add(m);
    wheels.push(m);
  } else if (kind === "truck") {
    put(new THREE.BoxGeometry(2.4, 1.45, 7.1), paint, 0, 1.2, 1.4);
    put(new THREE.BoxGeometry(2.15, 1.55, 2.35), paint, 0, 1.4, -3.1);
    put(new THREE.BoxGeometry(1.85, 0.5, 0.85), glass, 0, 1.9, -3.5);
    put(new THREE.BoxGeometry(0.24, 0.18, 0.08), tail, -0.85, 0.8, 4.95);
    put(new THREE.BoxGeometry(0.24, 0.18, 0.08), tail, 0.85, 0.8, 4.95);
    put(new THREE.BoxGeometry(0.3, 0.18, 0.08), head, -0.7, 0.85, -4.25);
    put(new THREE.BoxGeometry(0.3, 0.18, 0.08), head, 0.7, 0.85, -4.25);
    addWheels(1.15, -3.25, 0.42);
    addWheels(1.15, 1.15, 0.42);
    addWheels(1.15, 3.45, 0.42);
  } else {
    put(new THREE.BoxGeometry(1.72, 0.46, 4.3), paint, 0, 0.62, 0);
    put(new THREE.BoxGeometry(1.52, 0.4, 1.9), paint, 0, 1.02, 0.32);
    put(new THREE.BoxGeometry(1.35, 0.34, 1.05), glass, 0, 1.05, -0.2);
    if (kind === "taxi") {
      const lamp = new THREE.MeshStandardMaterial({
        color: "#f0b429",
        emissive: "#f0b429",
        emissiveIntensity: 0.8,
      });
      put(new THREE.BoxGeometry(0.28, 0.14, 0.28), lamp, 0, 1.32, 0.15);
    }
    put(new THREE.BoxGeometry(0.24, 0.14, 0.06), tail, -0.6, 0.7, 2.16);
    put(new THREE.BoxGeometry(0.24, 0.14, 0.06), tail, 0.6, 0.7, 2.16);
    put(new THREE.BoxGeometry(0.32, 0.14, 0.06), head, -0.55, 0.62, -2.16);
    put(new THREE.BoxGeometry(0.32, 0.14, 0.06), head, 0.55, 0.62, -2.16);
    addWheels(0.78, -1.32, 0.32);
    addWheels(0.78, 1.28, 0.32);
  }

  const spotL = new THREE.SpotLight("#fff1cc", 0, 46, Math.PI / 8, 0.45, 1);
  spotL.position.set(-0.45, 0.9, -1.6);
  const spotR = new THREE.SpotLight("#fff1cc", 0, 46, Math.PI / 8, 0.45, 1);
  spotR.position.set(0.45, 0.9, -1.6);
  const target = new THREE.Object3D();
  target.position.set(0, 0.4, -18);
  g.add(spotL, spotR, target);
  spotL.target = target;
  spotR.target = target;

  return { group: g, wheels, paint, spots: [spotL, spotR] };
}

function facadeTexture(base: string) {
  const c = document.createElement("canvas");
  c.width = 128;
  c.height = 256;
  const g = c.getContext("2d");
  if (!g) return null;
  g.fillStyle = base;
  g.fillRect(0, 0, 128, 256);
  g.fillStyle = "rgba(0,0,0,0.06)";
  for (let y = 0; y < 256; y += 18) g.fillRect(0, y, 128, 2);
  for (let y = 14; y < 248; y += 28) {
    for (let x = 10; x < 118; x += 22) {
      g.fillStyle = Math.sin(x * 12.3 + y) > 0 ? "#d5e2ea" : "#8aa0ad";
      g.fillRect(x, y, 12, 16);
    }
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}

function emissiveWindows() {
  const c = document.createElement("canvas");
  c.width = 128;
  c.height = 256;
  const g = c.getContext("2d");
  if (!g) return null;
  g.fillStyle = "#000";
  g.fillRect(0, 0, 128, 256);
  for (let y = 14; y < 248; y += 28) {
    for (let x = 10; x < 118; x += 22) {
      if (Math.sin(x * 3.1 + y * 1.7) > 0.15) {
        g.fillStyle = "#ffcc77";
        g.fillRect(x, y, 12, 16);
      }
    }
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function signTexture(title: string, sub: string) {
  const c = document.createElement("canvas");
  c.width = 512;
  c.height = 256;
  const g = c.getContext("2d");
  if (!g) return null;
  g.fillStyle = "#163e86";
  g.fillRect(0, 0, 512, 256);
  g.fillStyle = "#f0b429";
  g.fillRect(0, 0, 512, 10);
  g.fillStyle = "#f6f1e7";
  g.direction = "rtl";
  g.textAlign = "center";
  g.font = "800 72px Tajawal, sans-serif";
  g.fillText(title, 256, 120);
  g.font = "500 36px Tajawal, sans-serif";
  g.fillStyle = "#d6e4ff";
  g.fillText(sub, 256, 185);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

class Sfx {
  ctx: AudioContext | null = null;
  gain: GainNode | null = null;
  osc: OscillatorNode | null = null;
  filter: BiquadFilterNode | null = null;
  on = true;

  unlock() {
    if (!this.ctx) {
      const ctx = new AudioContext();
      const gain = ctx.createGain();
      gain.gain.value = 0.0001;
      const filter = ctx.createBiquadFilter();
      filter.type = "lowpass";
      filter.frequency.value = 240;
      const osc = ctx.createOscillator();
      osc.type = "sawtooth";
      osc.frequency.value = 46;
      osc.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      this.ctx = ctx;
      this.gain = gain;
      this.osc = osc;
      this.filter = filter;
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
  }

  engine(speed: number, throttle: number) {
    if (!this.ctx || !this.osc || !this.gain || !this.filter || !this.on) {
      if (this.gain) this.gain.gain.value = 0.0001;
      return;
    }
    const k = Math.abs(speed);
    this.osc.frequency.value = 42 + k * 3.1 + throttle * 18;
    this.filter.frequency.value = 180 + k * 18;
    this.gain.gain.value = 0.018 + Math.min(0.04, k * 0.0015);
  }

  blip(freq: number, dur: number, type: OscillatorType, vol: number) {
    if (!this.ctx || !this.on) return;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = type;
    o.frequency.value = freq;
    g.gain.value = vol;
    o.connect(g);
    g.connect(this.ctx.destination);
    o.start();
    g.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + dur);
    o.stop(this.ctx.currentTime + dur + 0.02);
  }

  horn() {
    this.blip(340, 0.18, "square", 0.05);
    setTimeout(() => this.blip(280, 0.16, "square", 0.04), 90);
  }

  cash() {
    this.blip(660, 0.08, "sine", 0.05);
    setTimeout(() => this.blip(880, 0.1, "sine", 0.04), 70);
  }

  crash() {
    this.blip(90, 0.22, "sawtooth", 0.07);
  }

  radar() {
    this.blip(980, 0.12, "square", 0.05);
  }

  stop() {
    if (this.gain) this.gain.gain.value = 0.0001;
    void this.ctx?.close();
    this.ctx = null;
  }
}

const defaultCfg: PreviewCfg = {
  mode: "shift",
  vehicle: "micro",
  night: false,
  density: 1,
  paint: "#e6c27a",
  sound: true,
};

export function mountGame(
  canvas: HTMLCanvasElement,
  map: HTMLCanvasElement,
  onHud: (h: Hud) => void,
): GameHandle {
  const track = buildTrack();
  const save = loadSave();
  const sfx = new Sfx();
  sfx.on = save.sound;

  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false });
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.setClearColor("#9ec9e8");
  const scene = new THREE.Scene();
  scene.fog = new THREE.Fog("#b7d4ea", 70, 620);
  const camera = new THREE.PerspectiveCamera(70, 1, 0.15, 900);

  const hemi = new THREE.HemisphereLight("#d5ecf8", "#b7a07a", 1.05);
  const sun = new THREE.DirectionalLight("#fff2d2", 1.45);
  sun.position.set(-120, 180, 60);
  scene.add(hemi, sun);

  const ground = new THREE.Mesh(
    new THREE.CircleGeometry(980, 48),
    new THREE.MeshStandardMaterial({ color: "#d7c4a2", roughness: 1 }),
  );
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = -0.08;
  scene.add(ground);

  buildRoad(scene, track);
  const buildings = buildCity(scene, track);
  const lamps = buildLamps(scene, track);
  buildGantries(scene, track);
  buildPyramids(scene, track);
  const signs: THREE.Mesh[] = [];

  const pools = new Map<VehicleId, { body: THREE.InstancedMesh; glass: THREE.InstancedMesh; wheels: THREE.InstancedMesh; lights: THREE.InstancedMesh }>();
  const POOL = 40;
  const glassMat = new THREE.MeshStandardMaterial({ color: "#1c3c48", roughness: 0.18, metalness: 0.2 });
  const wheelMat = new THREE.MeshStandardMaterial({ color: "#16181c", roughness: 0.7 });
  const lightMat = new THREE.MeshStandardMaterial({ color: "#ff3030", emissive: "#ff2020", emissiveIntensity: 0.85 });
  for (const kind of KINDS) {
    const ge = trafficGeoms(kind);
    const bodyMat = new THREE.MeshStandardMaterial({ color: "#ffffff", roughness: 0.55, metalness: 0.08 });
    const mk = (geo: THREE.BufferGeometry, mat: THREE.Material) => {
      const m = new THREE.InstancedMesh(geo, mat, POOL);
      m.frustumCulled = false;
      m.count = POOL;
      scene.add(m);
      return m;
    };
    pools.set(kind, {
      body: mk(ge.body, bodyMat),
      glass: mk(ge.glass, glassMat),
      wheels: mk(ge.wheels, wheelMat),
      lights: mk(ge.lights, lightMat),
    });
  }

  const dummy = new THREE.Object3D();
  const hideAll = () => {
    dummy.position.set(0, -20, 0);
    dummy.scale.set(0, 0, 0);
    dummy.updateMatrix();
    for (const p of pools.values()) {
      for (let i = 0; i < POOL; i++) {
        p.body.setMatrixAt(i, dummy.matrix);
        p.glass.setMatrixAt(i, dummy.matrix);
        p.wheels.setMatrixAt(i, dummy.matrix);
        p.lights.setMatrixAt(i, dummy.matrix);
      }
    }
  };
  hideAll();

  let playerMesh = buildPlayer("micro", "#e6c27a");
  scene.add(playerMesh.group);

  const sparkGeo = new THREE.BoxGeometry(0.12, 0.12, 0.12);
  const sparkMat = new THREE.MeshBasicMaterial({ color: "#f0b429" });
  const sparks: { m: THREE.Mesh; v: THREE.Vector3; life: number }[] = [];
  for (let i = 0; i < 18; i++) {
    const m = new THREE.Mesh(sparkGeo, sparkMat);
    m.visible = false;
    scene.add(m);
    sparks.push({ m, v: new THREE.Vector3(), life: 0 });
  }

  const keys = new Set<string>();
  let probeKeys: Set<string> | null = null;
  let probeSteer: number | null = null;
  const touch = { steer: 0, throttle: 0, brake: 0 };

  const player = {
    x: 0,
    z: 0,
    yaw: 0,
    speed: 0,
    hint: 0,
    spin: 0,
  };

  let cfg: PreviewCfg = { ...defaultCfg, sound: save.sound };
  let phase: Phase = "menu";
  let money = 0;
  let km = 0;
  let time = 0;
  let crashes = 0;
  let pax: Pax[] = [];
  let waiting = track.stops.map(() => 2 + Math.floor(Math.random() * 4));
  let serviced = -1;
  let message = "";
  let messageT = 0;
  let alert: Hud["alert"] = null;
  let alertT = 0;
  let hitCd = 0;
  let hornCd = 0;
  let radarCd = 0;
  let tollLatch = false;
  let camMode = 1;
  let trialStartS = 0;
  let trialTravel = 0;
  const trialNeed = 1500;
  let shake = 0;
  let steerVis = 0;
  let wheelSpin = 0;
  let saveTick = 0;
  const npcs: Npc[] = [];
  const wrongs: Wrong[] = [
    { s: 200, speed: 8, lat: 8.15 },
    { s: 900, speed: 7, lat: 8.25 },
  ];
  const camPos = new THREE.Vector3(0, 8, 20);
  const look = new THREE.Vector3();
  const desired = new THREE.Vector3();
  let last = performance.now();
  let acc = 0;
  let hudAcc = 0;
  let raf = 0;
  let running = true;

  const placeOn = (s: number, lane: number) => {
    const sm = track.sample(s);
    const rx = Math.cos(sm.yaw);
    const rz = -Math.sin(sm.yaw);
    const lat = laneLat(lane);
    player.x = sm.x + rx * lat;
    player.z = sm.z + rz * lat;
    player.yaw = sm.yaw;
    player.hint = 0;
    player.speed = 0;
  };

  const bootCinematic = () => {
    placeOn(track.stops[0].s, 1);
    player.speed = 16;
  };
  bootCinematic();

  function densityCount() {
    return cfg.density === 0 ? 16 : cfg.density === 2 ? 40 : 28;
  }

  function spawnTraffic(around: number) {
    npcs.length = 0;
    const n = densityCount();
    const weights: VehicleId[] = [
      "malaky",
      "malaky",
      "malaky",
      "taxi",
      "micro",
      "micro",
      "tuktuk",
      "tuktuk",
      "truck",
    ];
    for (let i = 0; i < n; i++) {
      const kind = weights[i % weights.length];
      const spec = vehicleById(kind);
      const col = new THREE.Color(
        ["#f4f1ea", "#cfd3d8", "#24527e", "#c45c3e", "#e6c27a", "#3d6b62", "#8d939c"][i % 7],
      );
      if (kind === "taxi") col.set("#f0d78c");
      npcs.push({
        alive: true,
        kind,
        s: around + 18 + (i * 260) / n + (i % 5) * 6,
        lane: i % 4,
        laneTarget: i % 4,
        speed: spec.max * (0.45 + (i % 5) * 0.08),
        cruise: spec.max * (0.42 + (i % 4) * 0.1),
        brake: 0,
        color: col,
        nextLane: 4 + (i % 6),
      });
    }
    for (const pool of pools.values()) {
      if (pool.body.instanceColor) pool.body.instanceColor.needsUpdate = true;
    }
  }
  spawnTraffic(track.stops[0].s);

  function burst(x: number, z: number) {
    for (const s of sparks) {
      if (s.life > 0) continue;
      s.life = 0.45;
      s.m.visible = true;
      s.m.position.set(x, 0.6, z);
      s.v.set((Math.random() - 0.5) * 8, 2 + Math.random() * 4, (Math.random() - 0.5) * 8);
    }
  }

  function say(text: string) {
    message = text;
    messageT = 2.4;
  }

  function flash(kind: Hud["alert"]) {
    alert = kind;
    alertT = 0.45;
  }

  function swapPlayer(kind: VehicleId, hex: string) {
    scene.remove(playerMesh.group);
    playerMesh.group.traverse((obj) => {
      const mesh = obj as THREE.Mesh;
      if (mesh.geometry) mesh.geometry.dispose();
    });
    playerMesh = buildPlayer(kind, hex);
    scene.add(playerMesh.group);
    applyNight();
  }

  function applyNight() {
    const night = cfg.night;
    renderer.setClearColor(night ? "#070b14" : "#9ec9e8");
    scene.fog = new THREE.Fog(night ? "#070b14" : "#b7d4ea", night ? 40 : 80, night ? 420 : 640);
    hemi.color.set(night ? "#31445c" : "#d5ecf8");
    hemi.groundColor.set(night ? "#1a140e" : "#b7a07a");
    hemi.intensity = night ? 0.28 : 1.05;
    sun.intensity = night ? 0.18 : 1.45;
    for (const mat of buildings) mat.emissiveIntensity = night ? 0.95 : 0;
    lamps.emissiveIntensity = night ? 1.4 : 0.05;
    const spot = night ? 7.5 : 0.15;
    for (const s of playerMesh.spots) s.intensity = spot;
  }
  applyNight();

  function drawSigns() {
    for (const s of signs) {
      scene.remove(s);
      s.geometry.dispose();
      (s.material as THREE.Material).dispose();
    }
    signs.length = 0;
    for (const stop of track.stops) {
      const tex = signTexture(stop.name, "النزلة الجاية");
      if (!tex) continue;
      const mat = new THREE.MeshStandardMaterial({ map: tex, roughness: 0.6 });
      const sm = track.sample(stop.s - 70);
      const rx = Math.cos(sm.yaw);
      const rz = -Math.sin(sm.yaw);
      const mesh = new THREE.Mesh(new THREE.PlaneGeometry(7.2, 3.6), mat);
      mesh.position.set(sm.x + rx * 11.2, 3.3, sm.z + rz * 11.2);
      mesh.rotation.y = sm.yaw;
      scene.add(mesh);
      signs.push(mesh);
    }
  }
  void document.fonts?.ready.then(() => drawSigns());

  function persist() {
    if (money > save.bestMoney) save.bestMoney = money;
    if (km > save.bestKm) save.bestKm = km;
    save.sound = sfx.on;
    writeSave(save);
  }

  function specNow() {
    return vehicleById(cfg.vehicle);
  }

  function resetRun(startS: number) {
    money = 0;
    km = 0;
    time = 0;
    crashes = 0;
    pax = [];
    waiting = track.stops.map(() => 1 + Math.floor(Math.random() * 5));
    serviced = -1;
    hitCd = 0;
    radarCd = 0;
    tollLatch = false;
    trialStartS = startS;
    trialTravel = 0;
    message = "";
    alert = null;
    placeOn(startS, 2);
    spawnTraffic(startS);
    const spec = specNow();
    if (cfg.mode === "shift" && spec.seats === 0) say("التريلا بتكسب نولون على كل كيلو");
    else if (cfg.mode === "shift") say("خش يمين المحطة وهدّي عشان تركّب");
    else if (cfg.mode === "trial") say("اوصل النزلة قبل ما الوقت يطول");
    else say("الطريق قدامك");
  }

  function start(next: PreviewCfg) {
    cfg = { ...next };
    sfx.on = cfg.sound;
    swapPlayer(cfg.vehicle, cfg.paint);
    phase = "play";
    const startS = track.stops[2].s;
    resetRun(startS);
    sfx.unlock();
    publish();
  }

  function hud(): Hud {
    const spec = specNow();
    const proj = track.project(player.x, player.z, player.hint);
    let bestI = 0;
    let bestD = Infinity;
    for (let i = 0; i < track.stops.length; i++) {
      const d = wrapDelta(track.stops[i].s, proj.s, track.total);
      if (d > 0 && d < bestD) {
        bestD = d;
        bestI = i;
      }
    }
    const stop = track.stops[bestI];
    let hint = "";
    if (phase === "play" && cfg.mode !== "trial") {
      const relevant =
        waiting[bestI] > 0 || pax.some((p) => p.dest === bestI) || spec.freight > 0;
      if (relevant && bestD < 90 && proj.lat < 3.4) hint = "خش يمين وهدّي";
      else if (relevant && bestD < 40 && player.speed > 4) hint = "هدّي عند المحطة";
    }
    const goal = spec.freight > 0 ? 400 : 250;
    return {
      phase,
      speed: Math.round(Math.abs(player.speed) * 3.6),
      money: Math.round(money),
      km: Math.round(km * 10) / 10,
      time,
      crashes,
      passengers: pax.map((p) => ({ dest: track.stops[p.dest].name })),
      seats: spec.seats,
      stopName: stop.name,
      stopDist: Math.max(0, Math.round(bestD)),
      hint,
      mode: cfg.mode,
      vehicleName: spec.name,
      message: messageT > 0 ? message : "",
      alert: alertT > 0 ? alert : null,
      progress: proj.s / track.total,
      goal,
      goalNow: spec.freight > 0 ? km * spec.freight : money,
      trialLeft: Math.max(0, trialNeed - trialTravel),
      trialBest: false,
      bestMoney: Math.round(save.bestMoney),
      bestKm: Math.round(save.bestKm * 10) / 10,
      bestTrial: save.bestTrial,
      night: cfg.night,
      sound: sfx.on,
    };
  }

  function publish() {
    onHud(hud());
  }

  function step(dt: number) {
    const spec = specNow();
    const down = (code: string) => (probeKeys ? probeKeys.has(code) : keys.has(code));

    let steer = 0;
    let throttle = 0;
    let brake = 0;
    if (phase === "play") {
      if (probeSteer != null) steer = probeSteer;
      else {
        if (down("KeyA") || down("ArrowLeft")) steer += 1;
        if (down("KeyD") || down("ArrowRight")) steer -= 1;
        steer += touch.steer;
      }
      if (down("KeyW") || down("ArrowUp")) throttle = 1;
      if (down("KeyS") || down("ArrowDown")) brake = 1;
      throttle = Math.max(throttle, touch.throttle);
      brake = Math.max(brake, touch.brake);
      steer = Math.max(-1, Math.min(1, steer));
    } else if (phase === "menu") {
      throttle = 0.62;
      const proj0 = track.project(player.x, player.z, player.hint);
      const want = laneLat(1);
      const err = want - proj0.lat;
      const dy = wrapAngle(proj0.yaw - player.yaw);
      steer = Math.max(-1, Math.min(1, err * 0.18 + dy * 1.4));
    }

    steerVis = steer;

    if (phase === "play" || phase === "menu") {
      if (throttle > 0 && brake === 0) player.speed += spec.accel * throttle * dt;
      else if (brake > 0) {
        if (player.speed > 0.5) player.speed -= spec.brake * dt;
        else player.speed -= spec.accel * 0.45 * dt;
      } else {
        const sign = Math.sign(player.speed);
        const mag = Math.max(0, Math.abs(player.speed) - 3.2 * dt);
        player.speed = sign * mag;
      }
      player.speed = Math.max(-7, Math.min(spec.max, player.speed));

      const sp = Math.min(1, Math.abs(player.speed) / 7);
      const reverse = player.speed < -0.5 ? -1 : 1;
      const turnMul = 0.35 + 0.65 * sp;
      player.yaw += steer * spec.turn * turnMul * reverse * dt;

      const fx = -Math.sin(player.yaw);
      const fz = -Math.cos(player.yaw);
      player.x += fx * player.speed * dt;
      player.z += fz * player.speed * dt;

      const proj = track.project(player.x, player.z, player.hint);
      player.hint = proj.i;
      const limit = ROAD_HALF - spec.width * 0.5;
      if (Math.abs(proj.lat) > limit) {
        const clamped = Math.sign(proj.lat) * limit;
        const rx = Math.cos(proj.yaw);
        const rz = -Math.sin(proj.yaw);
        player.x = proj.x + rx * clamped;
        player.z = proj.z + rz * clamped;
        const impact = Math.abs(proj.lat) - limit;
        if (impact > 0.08) {
          player.speed *= 0.9;
          shake = Math.max(shake, 0.12);
        }
      }

      const along = (() => {
        const tx = -Math.sin(proj.yaw);
        const tz = -Math.cos(proj.yaw);
        return (fx * tx + fz * tz) * player.speed;
      })();

      if (phase === "play") {
        if (along > 0) {
          km += (along * dt) / 1000;
          trialTravel += along * dt;
          if (spec.freight > 0 && cfg.mode === "shift") money += (along * dt * spec.freight) / 1000;
        }
        time += dt;
        if (cfg.mode === "trial" && trialTravel >= trialNeed) {
          phase = "summary";
          const prev = save.bestTrial;
          if (prev == null || time < prev) {
            save.bestTrial = time;
            say("رقم جديد");
          } else say("خلّصت المشوار");
          persist();
          sfx.cash();
        }
      }
    }

    hitCd = Math.max(0, hitCd - dt);
    hornCd = Math.max(0, hornCd - dt);
    radarCd = Math.max(0, radarCd - dt);
    messageT = Math.max(0, messageT - dt);
    alertT = Math.max(0, alertT - dt);
    shake = Math.max(0, shake - dt);

    updateNpcs(dt, spec.length);
    if (phase === "play") gameplay(dt);

    sfx.engine(player.speed, throttle);
    saveTick += dt;
    if (saveTick > 1.2) {
      saveTick = 0;
      if (money > save.bestMoney) save.bestMoney = money;
      if (km > save.bestKm) save.bestKm = km;
      writeSave(save);
    }
  }

  function updateNpcs(dt: number, _len: number) {
    const proj = track.project(player.x, player.z, player.hint);
    for (const n of npcs) {
      if (!n.alive) continue;
      const spec = vehicleById(n.kind);
      let target = n.cruise;
      const ahead = wrapDelta(n.s, proj.s, track.total);
      if (n.kind === "micro") {
        for (const stop of track.stops) {
          const d = wrapDelta(stop.s, n.s, track.total);
          if (d > 0 && d < 36 && n.lane > 1.5) target = Math.min(target, 3.5);
        }
        n.brake -= dt;
        if (n.brake <= 0 && Math.random() < dt * 0.15) n.brake = 1.3;
        if (n.brake > 0) target = Math.min(target, 2.2);
      }
      for (const o of npcs) {
        if (o === n || !o.alive) continue;
        if (Math.abs(o.lane - n.lane) > 0.75) continue;
        const gap = wrapDelta(o.s, n.s, track.total);
        if (gap > 0 && gap < 14) target = Math.min(target, o.speed * 0.92);
      }
      n.speed += (target - n.speed) * Math.min(1, dt * 1.4);
      n.speed = Math.max(2, n.speed);
      n.s += n.speed * dt;
      n.nextLane -= dt;
      if (n.nextLane <= 0) {
        n.nextLane = 3 + Math.random() * 5;
        const dir = Math.random() < 0.5 ? -1 : 1;
        n.laneTarget = Math.max(0, Math.min(3, Math.round(n.lane + dir)));
        if (n.kind === "tuktuk" && Math.random() < 0.4) {
          n.laneTarget = Math.random() < 0.5 ? 0 : 3;
        }
      }
      const blocked = npcs.some((o) => {
        if (o === n) return false;
        return Math.abs(o.lane - n.laneTarget) < 0.4 && Math.abs(wrapDelta(o.s, n.s, track.total)) < 8;
      });
      if (!blocked) {
        const diff = n.laneTarget - n.lane;
        const stepL = Math.max(-1, Math.min(1, diff)) * dt * 0.85;
        n.lane += stepL;
      }
      if (ahead < -30 || ahead > 340) {
        n.s = proj.s + 180 + Math.random() * 150;
        n.lane = Math.floor(Math.random() * 4);
        n.laneTarget = n.lane;
        n.cruise = spec.max * (0.4 + Math.random() * 0.35);
      }
    }

    for (const w of wrongs) {
      w.s -= w.speed * dt;
      const rel = wrapDelta(w.s, proj.s, track.total);
      if (rel < -40) w.s = proj.s + 160 + Math.random() * 80;
      if (phase !== "play" || hitCd > 0) continue;
      const sm = track.sample(w.s);
      const rx = Math.cos(sm.yaw);
      const rz = -Math.sin(sm.yaw);
      const x = sm.x + rx * w.lat;
      const z = sm.z + rz * w.lat;
      const d = Math.hypot(player.x - x, player.z - z);
      if (d < specNow().length * 0.42 + 1.3) collide(d, player.x - x, player.z - z, 10);
    }
  }

  function collide(dist: number, dx: number, dz: number, otherSpeed: number) {
    const spec = specNow();
    const d = Math.max(0.001, dist);
    const push = 0.8;
    player.x += (dx / d) * push;
    player.z += (dz / d) * push;
    const rel = Math.abs(player.speed - otherSpeed);
    player.speed *= 0.62;
    hitCd = 0.65;
    shake = 0.35;
    if (rel > 5 && phase === "play") {
      crashes += 1;
      player.yaw += (Math.random() - 0.5) * 0.35;
      if (cfg.mode === "shift") {
        money = Math.max(0, money - 40);
        if (pax.length) {
          pax.pop();
          say("راكب نزل غصب — غرامة");
        } else say("خبطة! غرامة ٤٠ ج");
      } else if (cfg.mode === "trial") {
        time += 2.5;
        say("خبطة +٢.٥ ث");
      } else say("خبطة! خد بالك");
      flash("crash");
      sfx.crash();
      burst(player.x, player.z);
    }
  }

  function gameplay(dt: number) {
    const spec = specNow();
    const proj = track.project(player.x, player.z, player.hint);
    for (const n of npcs) {
      if (!n.alive || hitCd > 0) continue;
      const sm = track.sample(n.s);
      const rx = Math.cos(sm.yaw);
      const rz = -Math.sin(sm.yaw);
      const lat = laneLat(n.lane);
      const x = sm.x + rx * lat;
      const z = sm.z + rz * lat;
      const reach = spec.length * 0.42 + vehicleById(n.kind).length * 0.4;
      const d = Math.hypot(player.x - x, player.z - z);
      if (d < reach) {
        n.speed *= 0.75;
        collide(d, player.x - x, player.z - z, n.speed);
        break;
      }
    }

    if (hornCd > 0.72) {
      for (const n of npcs) {
        const gap = wrapDelta(n.s, proj.s, track.total);
        if (gap > 0 && gap < 22 && Math.abs(laneLat(n.lane) - proj.lat) < 4) {
          n.laneTarget = proj.lat > laneLat(n.lane) ? Math.max(0, n.lane - 1) : Math.min(3, n.lane + 1);
        }
      }
    }

    const nearStop = (index: number) => {
      const d = Math.abs(wrapDelta(track.stops[index].s, proj.s, track.total));
      return d < 18 && proj.lat > 3.5 && Math.abs(player.speed) < 4.2;
    };

    if (serviced >= 0) {
      const away = Math.abs(wrapDelta(track.stops[serviced].s, proj.s, track.total));
      if (away > 36) {
        if (waiting[serviced] <= 0) waiting[serviced] = 1 + Math.floor(Math.random() * 5);
        serviced = -1;
      }
    }

    if (cfg.mode === "shift" && spec.seats > 0) {
      for (let i = 0; i < track.stops.length; i++) {
        if (!nearStop(i) || serviced === i) continue;
        const dropping = pax.filter((p) => p.dest === i);
        if (dropping.length) {
          const pay = Math.round(dropping.length * 28 * spec.fare);
          money += pay;
          pax = pax.filter((p) => p.dest !== i);
          say(`نزلوا — +${pay} ج`);
          flash("cash");
          sfx.cash();
        }
        const free = spec.seats - pax.length;
        if (free > 0 && waiting[i] > 0) {
          const n = Math.min(free, waiting[i]);
          for (let k = 0; k < n; k++) {
            const hop = 2 + Math.floor(Math.random() * 3);
            pax.push({ dest: (i + hop) % track.stops.length });
          }
          waiting[i] -= n;
          say(`ركّبت ${n}`);
          sfx.cash();
        }
        serviced = i;
      }
    }

    if (radarCd <= 0) {
      for (const rs of track.radarS) {
        if (Math.abs(wrapDelta(rs, proj.s, track.total)) < 16 && Math.abs(player.speed) > RADAR_LIMIT) {
          radarCd = 8;
          flash("radar");
          sfx.radar();
          if (cfg.mode === "trial") {
            time += 1.5;
            say("رادار +١.٥ ث");
          } else {
            money = Math.max(0, money - 80);
            say("رادار! غرامة ٨٠ ج");
          }
          break;
        }
      }
    }

    const tollD = wrapDelta(track.tollS, proj.s, track.total);
    if (tollD > -8 && tollD < 16) {
      if (!tollLatch && player.speed > TOLL_LIMIT) {
        tollLatch = true;
        player.speed = Math.min(player.speed, TOLL_LIMIT);
        if (cfg.mode === "trial") {
          time += 1;
          say("البوابة عايزة تهدية");
        } else {
          money = Math.max(0, money - 20);
          say("بوابة — ٢٠ ج");
        }
      }
    } else if (Math.abs(tollD) > 40) tollLatch = false;

    if (alongWrong(proj) && messageT <= 0) say("إنت عكس الاتجاه");
  }

  function alongWrong(proj: { yaw: number }) {
    const fx = -Math.sin(player.yaw);
    const fz = -Math.cos(player.yaw);
    const tx = -Math.sin(proj.yaw);
    const tz = -Math.cos(proj.yaw);
    return fx * tx + fz * tz < -0.45 && Math.abs(player.speed) > 3;
  }

  function render(dt: number) {
    const fwX = -Math.sin(player.yaw);
    const fwZ = -Math.cos(player.yaw);
    const dist = camMode === 0 ? 6.5 : camMode === 2 ? 16 : camMode === 3 ? 0.2 : 11;
    const height = camMode === 3 ? 1.35 : 3.1 + camMode * 0.45;
    const back = camMode === 3 ? -1.15 : dist;
    desired.set(player.x - fwX * back, height, player.z - fwZ * back);
    if (shake > 0) {
      desired.x += (Math.random() - 0.5) * shake * 1.4;
      desired.y += (Math.random() - 0.5) * shake;
    }
    const k = 1 - Math.exp(-5 * dt);
    camPos.lerp(desired, phase === "menu" ? Math.min(1, k * 1.2) : k);
    camera.position.copy(camPos);
    const lookAhead = camMode === 3 ? 14 : 7;
    look.set(player.x + fwX * lookAhead, camMode === 3 ? 1.1 : 1.2, player.z + fwZ * lookAhead);
    camera.lookAt(look);
    const base = camMode === 3 ? 78 : 68;
    camera.fov = base + Math.min(1, Math.abs(player.speed) / 30) * 8;
    camera.updateProjectionMatrix();

    playerMesh.group.position.set(player.x, 0, player.z);
    playerMesh.group.rotation.y = player.yaw;
    playerMesh.group.rotation.z = steerVis * -0.045;
    playerMesh.group.rotation.x = (player.speed > 1 ? -0.02 : 0.03) * Math.min(1, Math.abs(player.speed) / 20);
    wheelSpin += player.speed * dt * 2.2;
    for (const w of playerMesh.wheels) w.rotation.x = wheelSpin;

    const cursors: Record<VehicleId, number> = {
      malaky: 0,
      taxi: 0,
      micro: 0,
      tuktuk: 0,
      truck: 0,
    };
    const paintNpc = (kind: VehicleId, s: number, yaw: number, lat: number, color?: THREE.Color) => {
      const pool = pools.get(kind)!;
      const i = cursors[kind]++;
      if (i >= POOL) return;
      const sm = track.sample(s);
      const rx = Math.cos(sm.yaw);
      const rz = -Math.sin(sm.yaw);
      dummy.position.set(sm.x + rx * lat, 0, sm.z + rz * lat);
      dummy.rotation.set(0, yaw, 0);
      dummy.scale.set(1, 1, 1);
      dummy.updateMatrix();
      pool.body.setMatrixAt(i, dummy.matrix);
      pool.glass.setMatrixAt(i, dummy.matrix);
      pool.wheels.setMatrixAt(i, dummy.matrix);
      pool.lights.setMatrixAt(i, dummy.matrix);
      if (color) pool.body.setColorAt(i, color);
    };

    for (const n of npcs) {
      if (!n.alive) continue;
      const sm = track.sample(n.s);
      paintNpc(n.kind, n.s, sm.yaw, laneLat(n.lane), n.color);
    }
    const tukColor = new THREE.Color("#d4654a");
    for (const w of wrongs) {
      const sm = track.sample(w.s);
      paintNpc("tuktuk", w.s, sm.yaw + Math.PI, w.lat, tukColor);
    }
    dummy.scale.set(0, 0, 0);
    dummy.position.set(0, -30, 0);
    dummy.updateMatrix();
    for (const kind of KINDS) {
      const pool = pools.get(kind)!;
      for (let i = cursors[kind]; i < POOL; i++) {
        pool.body.setMatrixAt(i, dummy.matrix);
        pool.glass.setMatrixAt(i, dummy.matrix);
        pool.wheels.setMatrixAt(i, dummy.matrix);
        pool.lights.setMatrixAt(i, dummy.matrix);
      }
      pool.body.instanceMatrix.needsUpdate = true;
      pool.glass.instanceMatrix.needsUpdate = true;
      pool.wheels.instanceMatrix.needsUpdate = true;
      pool.lights.instanceMatrix.needsUpdate = true;
      if (pool.body.instanceColor) pool.body.instanceColor.needsUpdate = true;
    }

    for (const s of sparks) {
      if (s.life <= 0) continue;
      s.life -= dt;
      s.v.y -= 9 * dt;
      s.m.position.addScaledVector(s.v, dt);
      if (s.life <= 0) s.m.visible = false;
    }

    drawMap();
    renderer.render(scene, camera);
  }

  const mapPts = track.pts.filter((_, i) => i % 2 === 0);
  let minX = Infinity;
  let maxX = -Infinity;
  let minZ = Infinity;
  let maxZ = -Infinity;
  for (const p of mapPts) {
    minX = Math.min(minX, p.x);
    maxX = Math.max(maxX, p.x);
    minZ = Math.min(minZ, p.z);
    maxZ = Math.max(maxZ, p.z);
  }

  function drawMap() {
    const ctx = map.getContext("2d");
    if (!ctx) return;
    const w = map.width;
    const h = map.height;
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = "rgba(20,24,30,0.72)";
    ctx.beginPath();
    ctx.arc(w / 2, h / 2, w / 2 - 2, 0, Math.PI * 2);
    ctx.fill();
    const pad = 16;
    const sx = (w - pad * 2) / (maxX - minX || 1);
    const sy = (h - pad * 2) / (maxZ - minZ || 1);
    const sc = Math.min(sx, sy);
    const ox = w / 2 - ((minX + maxX) / 2) * sc;
    const oy = h / 2 - ((minZ + maxZ) / 2) * sc;
    const px = (x: number, z: number) => [ox + x * sc, oy + z * sc] as const;
    ctx.beginPath();
    mapPts.forEach((p, i) => {
      const [x, y] = px(p.x, p.z);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.closePath();
    ctx.strokeStyle = "#f0b429";
    ctx.lineWidth = 3;
    ctx.stroke();
    ctx.fillStyle = "#1aa6a6";
    for (const stop of track.stops) {
      const sm = track.sample(stop.s);
      const [x, y] = px(sm.x, sm.z);
      ctx.fillRect(x - 1.5, y - 1.5, 3, 3);
    }
    const [x, y] = px(player.x, player.z);
    ctx.fillStyle = "#f6f1e7";
    ctx.beginPath();
    ctx.arc(x, y, 3.5, 0, Math.PI * 2);
    ctx.fill();
  }

  function frame(now: number) {
    if (!running) return;
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    acc += dt;
    let steps = 0;
    while (acc >= 1 / 60 && steps < 5) {
      if (phase !== "pause" && phase !== "summary") step(1 / 60);
      acc -= 1 / 60;
      steps++;
    }
    render(dt);
    hudAcc += dt;
    if (hudAcc > 0.12) {
      hudAcc = 0;
      if (phase === "play" || phase === "summary" || phase === "pause") publish();
    }
    raf = requestAnimationFrame(frame);
  }

  function resize() {
    const w = canvas.clientWidth || 1;
    const h = canvas.clientHeight || 1;
    const dpr = Math.min(window.devicePixelRatio || 1, 1.6);
    renderer.setPixelRatio(dpr);
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }
  resize();
  const ro = new ResizeObserver(() => resize());
  ro.observe(canvas);

  const onDown = (e: KeyboardEvent) => {
    if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.code)) e.preventDefault();
    keys.add(e.code);
    if (e.repeat) return;
    if (e.code === "Space" || e.code === "KeyH") honk();
    if (e.code === "KeyC") cycleCam();
    if (e.code === "Escape") {
      if (phase === "play") phase = "pause";
      else if (phase === "pause") phase = "play";
      publish();
    }
  };
  const onUp = (e: KeyboardEvent) => keys.delete(e.code);
  const onBlur = () => keys.clear();
  window.addEventListener("keydown", onDown);
  window.addEventListener("keyup", onUp);
  window.addEventListener("blur", onBlur);

  function honk() {
    if (hornCd > 0) return;
    hornCd = 0.85;
    sfx.unlock();
    sfx.horn();
  }

  function cycleCam() {
    camMode = (camMode + 1) % 4;
  }

  window.__controlsTest = {
    getYaw: () => player.yaw,
    getSpeed: () => player.speed,
    setKeys: (codes: string[]) => {
      probeKeys = codes.length ? new Set(codes) : null;
      if (probeKeys && phase !== "play") start(cfg);
    },
    setSteer: (v: number) => {
      probeSteer = v;
    },
  };

  publish();
  raf = requestAnimationFrame(frame);

  return {
    getHud: hud,
    setPreview: (next) => {
      const vehicleChanged = next.vehicle !== cfg.vehicle || next.paint !== cfg.paint;
      const nightChanged = next.night !== cfg.night;
      cfg = { ...next };
      sfx.on = cfg.sound;
      save.sound = cfg.sound;
      writeSave(save);
      if (vehicleChanged && phase === "menu") swapPlayer(cfg.vehicle, cfg.paint);
      if (nightChanged) applyNight();
      if (phase === "menu") publish();
    },
    start,
    pause: () => {
      if (phase === "play") {
        phase = "pause";
        publish();
      }
    },
    resume: () => {
      if (phase === "pause") {
        phase = "play";
        publish();
      }
    },
    quit: () => {
      persist();
      phase = "menu";
      probeKeys = null;
      bootCinematic();
      spawnTraffic(track.stops[0].s);
      publish();
    },
    finish: () => {
      if (phase !== "play") return;
      phase = "summary";
      persist();
      say(cfg.mode === "trial" ? "وقفت الساعة" : "خلصت الوردية");
      publish();
    },
    setTouch: (t) => {
      touch.steer = t.steer;
      touch.throttle = t.throttle;
      touch.brake = t.brake;
    },
    horn: honk,
    cycleCam,
    toggleSound: () => {
      sfx.on = !sfx.on;
      cfg.sound = sfx.on;
      save.sound = sfx.on;
      writeSave(save);
      if (sfx.on) sfx.unlock();
      publish();
    },
    dispose: () => {
      running = false;
      cancelAnimationFrame(raf);
      ro.disconnect();
      window.removeEventListener("keydown", onDown);
      window.removeEventListener("keyup", onUp);
      window.removeEventListener("blur", onBlur);
      if (window.__controlsTest?.getYaw === (() => player.yaw) || window.__controlsTest) {
        delete window.__controlsTest;
      }
      sfx.stop();
      renderer.dispose();
    },
  };
}

const LANE_STEP = 3.6;

function buildRoad(scene: THREE.Scene, track: Track) {
  const pts = track.pts;
  const half = ROAD_HALF;
  const positions: number[] = [];
  const colors: number[] = [];
  const n = pts.length;
  const edge = (i: number, lat: number) => {
    const p = pts[i];
    const rx = Math.cos(p.yaw);
    const rz = -Math.sin(p.yaw);
    return [p.x + rx * lat, 0.02, p.z + rz * lat] as const;
  };
  for (let i = 0; i < n; i++) {
    const a = edge(i, -half);
    const b = edge(i, half);
    const c = edge((i + 1) % n, -half);
    const d = edge((i + 1) % n, half);
    positions.push(...a, ...b, ...d, ...a, ...d, ...c);
    for (let k = 0; k < 6; k++) {
      const shade = 0.28 + ((i + k) % 5) * 0.012;
      colors.push(shade, shade + 0.005, shade + 0.01);
    }
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute("color", new THREE.Float32BufferAttribute(colors, 3));
  geo.computeVertexNormals();
  const mat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.92, metalness: 0 });
  scene.add(new THREE.Mesh(geo, mat));

  const dashes: THREE.Matrix4[] = [];
  const dash = new THREE.Object3D();
  for (let i = 0; i < n; i += 3) {
    const p = pts[i];
    const rx = Math.cos(p.yaw);
    const rz = -Math.sin(p.yaw);
    for (const boundary of [-LANE_STEP, 0, LANE_STEP]) {
      dash.position.set(p.x + rx * boundary, 0.05, p.z + rz * boundary);
      dash.rotation.set(0, p.yaw, 0);
      dash.scale.set(1, 1, 1);
      dash.updateMatrix();
      dashes.push(dash.matrix.clone());
    }
  }
  const dashMesh = new THREE.InstancedMesh(
    new THREE.BoxGeometry(0.12, 0.02, 2.4),
    new THREE.MeshStandardMaterial({ color: "#f4f1ea", roughness: 0.5 }),
    dashes.length,
  );
  dashes.forEach((m, i) => dashMesh.setMatrixAt(i, m));
  scene.add(dashMesh);

  const bars: THREE.Matrix4[] = [];
  const bar = new THREE.Object3D();
  for (let i = 0; i < n; i += 2) {
    const p = pts[i];
    const rx = Math.cos(p.yaw);
    const rz = -Math.sin(p.yaw);
    for (const side of [-1, 1]) {
      bar.position.set(p.x + rx * side * (half + 0.45), 0.42, p.z + rz * side * (half + 0.45));
      bar.rotation.set(0, p.yaw, 0);
      bar.updateMatrix();
      bars.push(bar.matrix.clone());
    }
  }
  const barMesh = new THREE.InstancedMesh(
    new THREE.BoxGeometry(0.55, 0.82, 3.3),
    new THREE.MeshStandardMaterial({ color: "#d9d3c6", roughness: 0.8 }),
    bars.length,
  );
  bars.forEach((m, i) => barMesh.setMatrixAt(i, m));
  scene.add(barMesh);

  const edgeMat = new THREE.MeshStandardMaterial({ color: "#f0b429", roughness: 0.45 });
  const edges: number[] = [];
  for (const side of [-1, 1]) {
    for (let i = 0; i < n; i++) {
      const a = edge(i, side * (half - 0.18));
      const b = edge(i, side * (half - 0.02));
      const c = edge((i + 1) % n, side * (half - 0.18));
      const d = edge((i + 1) % n, side * (half - 0.02));
      edges.push(...a, ...b, ...d, ...a, ...d, ...c);
    }
  }
  const eg = new THREE.BufferGeometry();
  eg.setAttribute("position", new THREE.Float32BufferAttribute(edges, 3));
  eg.computeVertexNormals();
  scene.add(new THREE.Mesh(eg, edgeMat));
}

function buildCity(scene: THREE.Scene, track: Track) {
  const bases = ["#e7d3b5", "#e2b39a", "#efe6d6", "#cfc8ba", "#c46a52"];
  const emissive = emissiveWindows();
  const mats: THREE.MeshStandardMaterial[] = [];
  const geos = new THREE.BoxGeometry(1, 1, 1);
  const meshes: THREE.InstancedMesh[] = [];
  bases.forEach((hex) => {
    const map = facadeTexture(hex);
    const mat = new THREE.MeshStandardMaterial({
      color: "#ffffff",
      map: map ?? undefined,
      emissive: "#ffcc77",
      emissiveMap: emissive ?? undefined,
      emissiveIntensity: 0,
      roughness: 0.86,
    });
    mats.push(mat);
    const mesh = new THREE.InstancedMesh(geos, mat, 160);
    mesh.count = 0;
    scene.add(mesh);
    meshes.push(mesh);
  });
  const counts = bases.map(() => 0);
  const dummy = new THREE.Object3D();
  const tanks: THREE.Matrix4[] = [];
  const tankO = new THREE.Object3D();
  const pts = track.pts;
  for (let i = 0; i < pts.length; i += 5) {
    const p = pts[i];
    const rx = Math.cos(p.yaw);
    const rz = -Math.sin(p.yaw);
    const hsh = Math.abs(Math.sin(i * 12.9898) * 43758.5453) % 1;
    const side = i % 10 === 0 ? -1 : 1;
    const depth = side > 0 ? 14 + hsh * 16 : 22 + hsh * 18;
    const height = 8 + hsh * 38;
    const width = 8 + (hsh * 7);
    const deep = 8 + ((1 - hsh) * 6);
    const idx = i % meshes.length;
    if (counts[idx] >= 160) continue;
    dummy.position.set(p.x + rx * side * depth, height / 2, p.z + rz * side * depth);
    dummy.rotation.set(0, p.yaw, 0);
    dummy.scale.set(width, height, deep);
    dummy.updateMatrix();
    meshes[idx].setMatrixAt(counts[idx]++, dummy.matrix);
    if (hsh > 0.55) {
      tankO.position.set(p.x + rx * side * depth, height + 0.7, p.z + rz * side * depth);
      tankO.scale.set(1, 1, 1);
      tankO.rotation.set(0, 0, 0);
      tankO.updateMatrix();
      tanks.push(tankO.matrix.clone());
    }
  }
  meshes.forEach((m, i) => {
    m.count = counts[i];
    m.instanceMatrix.needsUpdate = true;
    m.computeBoundingSphere();
  });
  if (tanks.length) {
    const tankMesh = new THREE.InstancedMesh(
      new THREE.CylinderGeometry(0.8, 0.8, 1.3, 8),
      new THREE.MeshStandardMaterial({ color: "#9aa1a8", roughness: 0.55, metalness: 0.2 }),
      tanks.length,
    );
    tanks.forEach((m, i) => tankMesh.setMatrixAt(i, m));
    scene.add(tankMesh);
  }
  return mats;
}

function buildLamps(scene: THREE.Scene, track: Track) {
  const mats: THREE.Matrix4[] = [];
  const heads: THREE.Matrix4[] = [];
  const o = new THREE.Object3D();
  const pts = track.pts;
  for (let i = 0; i < pts.length; i += 8) {
    const p = pts[i];
    const rx = Math.cos(p.yaw);
    const rz = -Math.sin(p.yaw);
    o.position.set(p.x + rx * 11.4, 3.1, p.z + rz * 11.4);
    o.rotation.set(0, 0, 0);
    o.scale.set(1, 1, 1);
    o.updateMatrix();
    mats.push(o.matrix.clone());
    o.position.y = 6.3;
    o.updateMatrix();
    heads.push(o.matrix.clone());
  }
  const pole = new THREE.InstancedMesh(
    new THREE.CylinderGeometry(0.12, 0.16, 6.2, 6),
    new THREE.MeshStandardMaterial({ color: "#2c3138", roughness: 0.6 }),
    mats.length,
  );
  mats.forEach((m, i) => pole.setMatrixAt(i, m));
  scene.add(pole);
  const bulbMat = new THREE.MeshStandardMaterial({
    color: "#fff1cc",
    emissive: "#ffd78a",
    emissiveIntensity: 0.05,
  });
  const bulbs = new THREE.InstancedMesh(new THREE.SphereGeometry(0.28, 8, 8), bulbMat, heads.length);
  heads.forEach((m, i) => bulbs.setMatrixAt(i, m));
  scene.add(bulbs);
  return bulbMat;
}

function buildGantries(scene: THREE.Scene, track: Track) {
  const metal = new THREE.MeshStandardMaterial({ color: "#cfd5dc", roughness: 0.4, metalness: 0.3 });
  const cam = new THREE.MeshStandardMaterial({ color: "#f0b429", emissive: "#f0b429", emissiveIntensity: 0.3 });
  const add = (s: number, toll: boolean) => {
    const sm = track.sample(s);
    const rx = Math.cos(sm.yaw);
    const rz = -Math.sin(sm.yaw);
    const g = new THREE.Group();
    g.position.set(sm.x, 0, sm.z);
    g.rotation.y = sm.yaw;
    const poleL = new THREE.Mesh(new THREE.BoxGeometry(0.35, 6.2, 0.35), metal);
    poleL.position.set(-10, 3.1, 0);
    const poleR = new THREE.Mesh(new THREE.BoxGeometry(0.35, 6.2, 0.35), metal);
    poleR.position.set(10, 3.1, 0);
    const beam = new THREE.Mesh(new THREE.BoxGeometry(20.6, 0.45, 0.7), metal);
    beam.position.set(0, 6.2, 0);
    g.add(poleL, poleR, beam);
    if (!toll) {
      const eye = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.4, 0.8), cam);
      eye.position.set(0, 5.7, 0.4);
      g.add(eye);
    }
    scene.add(g);
  };
  for (const s of track.radarS) add(s, false);
  add(track.tollS, true);
}

function buildPyramids(scene: THREE.Scene, track: Track) {
  const stop = track.stops[1];
  const sm = track.sample(stop.s);
  const rx = Math.cos(sm.yaw);
  const rz = -Math.sin(sm.yaw);
  const mat = new THREE.MeshStandardMaterial({ color: "#d8c097", roughness: 0.92 });
  const sizes = [26, 20, 14];
  sizes.forEach((h, i) => {
    const geo = new THREE.ConeGeometry(h * 0.78, h, 4);
    const m = new THREE.Mesh(geo, mat);
    const along = -Math.sin(sm.yaw);
    const az = -Math.cos(sm.yaw);
    m.position.set(sm.x + rx * (34 + i * 16) + along * i * 18, h / 2, sm.z + rz * (34 + i * 16) + az * i * 18);
    m.rotation.y = Math.PI / 4;
    scene.add(m);
  });
}

declare global {
  interface Window {
    __controlsTest?: {
      getYaw: () => number;
      getSpeed: () => number;
      setKeys?: (codes: string[]) => void;
      setSteer?: (v: number) => void;
    };
  }
}
