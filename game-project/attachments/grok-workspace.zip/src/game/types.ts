export type VehicleId = "malaky" | "taxi" | "micro" | "tuktuk" | "truck";
export type Mode = "shift" | "cruise" | "trial";
export type Phase = "menu" | "play" | "pause" | "summary";

export type VehicleSpec = {
  id: VehicleId;
  name: string;
  blurb: string;
  max: number;
  accel: number;
  brake: number;
  turn: number;
  width: number;
  length: number;
  seats: number;
  fare: number;
  freight: number;
  speed: number;
  grip: number;
  haul: number;
};

export const VEHICLES: VehicleSpec[] = [
  {
    id: "malaky",
    name: "ملاكي",
    blurb: "متوازن وسريع",
    max: 34,
    accel: 16,
    brake: 30,
    turn: 1.7,
    width: 1.8,
    length: 4.4,
    seats: 3,
    fare: 1,
    freight: 0,
    speed: 4,
    grip: 4,
    haul: 2,
  },
  {
    id: "taxi",
    name: "تاكسي",
    blurb: "الأجرة أعلى",
    max: 32,
    accel: 15,
    brake: 28,
    turn: 1.62,
    width: 1.8,
    length: 4.5,
    seats: 3,
    fare: 1.45,
    freight: 0,
    speed: 4,
    grip: 3,
    haul: 3,
  },
  {
    id: "micro",
    name: "ميكروباص",
    blurb: "ركاب أكتر، مكسب أحلى",
    max: 27,
    accel: 12,
    brake: 20,
    turn: 1.28,
    width: 2.1,
    length: 5.1,
    seats: 11,
    fare: 1.05,
    freight: 0,
    speed: 3,
    grip: 2,
    haul: 5,
  },
  {
    id: "tuktuk",
    name: "توكتوك",
    blurb: "يلف في الزحمة",
    max: 18,
    accel: 13,
    brake: 22,
    turn: 2.45,
    width: 1.35,
    length: 2.55,
    seats: 2,
    fare: 0.72,
    freight: 0,
    speed: 2,
    grip: 5,
    haul: 1,
  },
  {
    id: "truck",
    name: "تريلا",
    blurb: "نولون بالكيلو، لف تقيل",
    max: 24,
    accel: 8,
    brake: 14,
    turn: 0.92,
    width: 2.45,
    length: 10.2,
    seats: 0,
    fare: 0,
    freight: 95,
    speed: 2,
    grip: 1,
    haul: 5,
  },
];

export const PAINTS = [
  { id: "sand", hex: "#e6c27a", name: "بيج", swatch: "bg-amber" },
  { id: "white", hex: "#f4f1ea", name: "أبيض", swatch: "bg-ink" },
  { id: "silver", hex: "#c5c8ce", name: "فضي", swatch: "bg-muted" },
  { id: "nile", hex: "#2f6f73", name: "نيلي", swatch: "bg-nile" },
  { id: "brick", hex: "#b5523a", name: "طوبي", swatch: "bg-brick" },
] as const;

export const MODES: { id: Mode; name: string; blurb: string }[] = [
  { id: "shift", name: "وردية", blurb: "ركّب ونزّل واكسب" },
  { id: "cruise", name: "فضاوة", blurb: "سوق على مهلك" },
  { id: "trial", name: "ضد الساعة", blurb: "اوصل النزلة بسرعة" },
];

export const DENSITIES = [
  { id: 0, name: "سالكة" },
  { id: 1, name: "زحمة" },
  { id: 2, name: "واقفة" },
] as const;

export type Pax = { dest: number };

export type Hud = {
  phase: Phase;
  speed: number;
  money: number;
  km: number;
  time: number;
  crashes: number;
  passengers: { dest: string }[];
  seats: number;
  stopName: string;
  stopDist: number;
  hint: string;
  mode: Mode;
  vehicleName: string;
  message: string;
  alert: null | "radar" | "crash" | "cash";
  progress: number;
  goal: number;
  goalNow: number;
  trialLeft: number;
  trialBest: boolean;
  bestMoney: number;
  bestKm: number;
  bestTrial: number | null;
  night: boolean;
  sound: boolean;
};

export type PreviewCfg = {
  mode: Mode;
  vehicle: VehicleId;
  night: boolean;
  density: number;
  paint: string;
  sound: boolean;
};

export const STOP_NAMES = [
  "المريوطية",
  "الهرم",
  "فيصل",
  "المنيب",
  "زهراء المعادي",
  "الأوتوستراد",
  "مدينة نصر",
  "السلام",
  "القناطر",
  "الوراق",
  "إمبابة",
  "المهندسين",
];

export function vehicleById(id: VehicleId) {
  return VEHICLES.find((v) => v.id === id) ?? VEHICLES[2];
}
